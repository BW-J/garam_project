// 실행 방법:
// 1. backend 폴더로 이동
// 2. npx ts-node -r tsconfig-paths/register scripts/seed-users.ts

import { DataSource } from 'typeorm';
import * as dotenv from 'dotenv';
import { User } from '../src/core/entities/tb_user.entity'; // 경로 확인 필요
import { EncryptionTransformer } from '../src/common/utils/encryption.transformer';
import { Department } from '../src/core/entities/tb_department.entity';
import { Position } from '../src/core/entities/tb_position.entity';
import { Bank } from '../src/core/entities/tb_bank.entity';
import { PositionRoleMap } from '../src/core/entities/tb_position_role_map.entity';
import { Role } from '../src/core/entities/tb_role.entity';
import { RolePermissions } from '../src/core/entities/tb_role_permissions.entity';
import { Menu } from '../src/core/entities/tb_menu.entity';
import { Action } from '../src/core/entities/tb_action.entity';
import { UserRoleMap } from '../src/core/entities/tb_user_role_map.entity';
import { UserPasswordHistory } from '../src/core/entities/tb_user_password_history';
import { UserClosure } from '../src/core/entities/tb_user_closure.entity';
import { UserPositionHistory } from '../src/core/entities/tb_user_position_history.entity';

// 1. 환경변수 로드 (암호화 키 가져오기 위해 필수)
dotenv.config({ path: '.env' });
// 또는 프로덕션인 경우: dotenv.config({ path: '.env.prod' });

async function seed() {
  if (!process.env.ENCRYPTION_KEY) {
    console.error('❌ .env 파일에서 ENCRYPTION_KEY를 찾을 수 없습니다.');
    return;
  }

  // 2. DB 연결 설정 (최소한의 설정)
  const dataSource = new DataSource({
    type: 'postgres',
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT) || 5432,
    username: process.env.DB_USERNAME || 'postgres',
    password: process.env.DB_PASSWORD || 'jung2806',
    database: process.env.DB_DATABASE || 'pg_database',
    entities: [
      User,
      Department,
      Position,
      Bank,
      PositionRoleMap,
      Role,
      RolePermissions,
      Menu,
      Action,
      UserRoleMap,
      UserPasswordHistory,
      UserClosure,
      UserPositionHistory,
    ], // User 엔티티만 로드
    synchronize: false,
  });

  await dataSource.initialize();
  console.log('✅ Data Source Initialized');

  const userRepo = dataSource.getRepository(User);

  // 3. 넣을 데이터 준비 (평문으로 작성)
  // (엑셀에서 읽어와서 배열로 만들어도 됩니다)
  const usersToUpdate = [
    { loginId: '2025090052', front: '680312', back: '2168336' },
    { loginId: '2023100082', front: '760209', back: '1496510' },
    { loginId: '2025090110', front: '740525', back: '2235316' },
    { loginId: '2025090107', front: '611029', back: '2850417' },
    { loginId: '2025090106', front: '891013', back: '1621711' },
    { loginId: '2025090103', front: '740303', back: '1167628' },
    { loginId: '2025090084', front: '650328', back: '1800515' },
    { loginId: '2025090083', front: '681017', back: '1067119' },
    { loginId: '2025090082', front: '730108', back: '1533114' },
    { loginId: '2025090045', front: '610701', back: '1143216' },
    { loginId: '2025090014', front: '751023', back: '1703029' },
    { loginId: '2025090053', front: '550410', back: '2037421' },
    { loginId: '2025090115', front: '570101', back: '1018021' },
    { loginId: '2025090104', front: '650416', back: '2905819' },
    { loginId: '2025090046', front: '771020', back: '1683310' },
    { loginId: '2025090344', front: '661206', back: '1663215' },
    { loginId: '2025090294', front: '640423', back: '1231612' },
    { loginId: '2025090293', front: '560309', back: '1639312' },
    { loginId: '2025090268', front: '780122', back: '2703013' },
    { loginId: '2025090265', front: '780313', back: '2683818' },
    { loginId: '2025090210', front: '770131', back: '2017513' },
    { loginId: '2025090208', front: '650126', back: '2781024' },
    { loginId: '2025090207', front: '610710', back: '2788129' },
    { loginId: '2025090206', front: '721103', back: '1773021' },
    { loginId: '2025090220', front: '620819', back: '1540816' },
    { loginId: '2025090114', front: '620121', back: '1041827' },
    { loginId: '2025090116', front: '660219', back: '2533413' },
    { loginId: '2025090085', front: '551123', back: '2105810' },
    { loginId: '2025090347', front: '730310', back: '2691216' },
    { loginId: '2025100032', front: '600813', back: '2520517' },
    { loginId: '2025090336', front: '771225', back: '2953419' },
    { loginId: '2025090279', front: '800119', back: '2155211' },
    { loginId: '2025090047', front: '540128', back: '2055722' },
    { loginId: '2025100010', front: '670923', back: '1535231' },
    { loginId: '2025090338', front: '740619', back: '2101022' },
    { loginId: '2025100026', front: '570111', back: '1331610' },
    { loginId: '2025090044', front: '710106', back: '2010032' },
    { loginId: '2025090048', front: '680816', back: '2449313' },
    { loginId: '2025090122', front: '720608', back: '1114241' },
    { loginId: '2025090050', front: '630416', back: '2042712' },
    { loginId: '2025100197', front: '610213', back: '2520527' },
    { loginId: '2025100174', front: '660325', back: '2382718' },
    { loginId: '2025100166', front: '700522', back: '2066821' },
    { loginId: '2025100165', front: '670118', back: '1030717' },
    { loginId: '2025100072', front: '711227', back: '1490112' },
    { loginId: '2025100012', front: '731215', back: '2392953' },
    { loginId: '2025090372', front: '711012', back: '2458310' },
    { loginId: '2025090362', front: '730709', back: '2465217' },
    { loginId: '2025100231', front: '950328', back: '2409511' },
    { loginId: '2025100140', front: '600121', back: '1447615' },
    { loginId: '2025090479', front: '781114', back: '2182421' },
    { loginId: '2025090013', front: '700814', back: '1030926' },
    { loginId: '2025090043', front: '990714', back: '2042127' },
    { loginId: '2025090041', front: '630504', back: '2382618' },
    { loginId: '2025090042', front: '941226', back: '1033315' },
    { loginId: '2025090111', front: '771023', back: '1079614' },
    { loginId: '2025090299', front: '711227', back: '2914214' },
    { loginId: '2025090300', front: '640101', back: '1623613' },
    { loginId: '2025090339', front: '710325', back: '2012119' },
    { loginId: '2025090276', front: '681020', back: '1390715' },
    { loginId: '2025090073', front: '671230', back: '2352515' },
    { loginId: '2025090197', front: '680707', back: '1051525' },
    { loginId: '2025100288', front: '730105', back: '6102994' },
    { loginId: '2025100226', front: '620303', back: '2386316' },
    { loginId: '2025100224', front: '530525', back: '2162516' },
    { loginId: '2025100161', front: '681221', back: '2520911' },
    { loginId: '2025090195', front: '570319', back: '1474018' },
    { loginId: '2025100286', front: '590415', back: '1408629' },
    { loginId: '2025100284', front: '631226', back: '2683318' },
    { loginId: '2025100222', front: '680408', back: '1539112' },
    { loginId: '2025110045', front: '640515', back: '2120413' },
    { loginId: '2025110035', front: '720201', back: '2574611' },
    { loginId: '2025110022', front: '601118', back: '1381011' },
    { loginId: '2025100289', front: '991222', back: '2051910' },
    { loginId: '2025090015', front: '700726', back: '2464312' },
    { loginId: '2025090123', front: '760223', back: '2921221' },
    { loginId: '2025090054', front: '810402', back: '2109310' },
    { loginId: '2025090304', front: '780727', back: '2118018' },
    { loginId: '2025100027', front: '790406', back: '2821411' },
    { loginId: '2025100024', front: '730811', back: '2106343' },
    { loginId: '2025100019', front: '810915', back: '1820111' },
    { loginId: '2025090323', front: '691230', back: '1105514' },
    { loginId: '2025090312', front: '650808', back: '1047117' },
    { loginId: '2025090307', front: '740102', back: '2120810' },
    { loginId: '2025100267', front: '921105', back: '1127112' },
    { loginId: '2025090393', front: '760210', back: '2449536' },
    { loginId: '2025090125', front: '890803', back: '1247610' },
    { loginId: '2025090124', front: '680102', back: '2808014' },
    { loginId: '2025090062', front: '710514', back: '1101414' },
    { loginId: '2025090063', front: '691219', back: '2481213' },
    { loginId: '2025090064', front: '741211', back: '1683511' },
    { loginId: '2025090087', front: '740422', back: '1110515' },
    { loginId: '2025090465', front: '730403', back: '1122820' },
    { loginId: '2025090270', front: '681007', back: '1042725' },
    { loginId: '2025090212', front: '721205', back: '1382625' },
    { loginId: '2025090065', front: '610919', back: '1390715' },
    { loginId: '2025090394', front: '760116', back: '1462611' },
    { loginId: '2025090373', front: '771103', back: '2469313' },
    { loginId: '2025090320', front: '791023', back: '2469311' },
    { loginId: '2025090066', front: '710815', back: '1453228' },
    { loginId: '2025090327', front: '690910', back: '2392611' },
    { loginId: '2025090079', front: '600505', back: '2453411' },
    { loginId: '2025090232', front: '660125', back: '2794514' },
    { loginId: '2025110042', front: '700729', back: '2163027' },
    { loginId: '2025090119', front: '650613', back: '1480411' },
    { loginId: '2025090118', front: '721210', back: '2318818' },
    { loginId: '2025090117', front: '720102', back: '2544129' },
    { loginId: '2025090071', front: '601001', back: '1489913' },
    { loginId: '2025090069', front: '790930', back: '2523217' },
    { loginId: '2025090075', front: '790915', back: '2481711' },
    { loginId: '2025090282', front: '671008', back: '1480210' },
    { loginId: '2025090068', front: '710913', back: '2523018' },
    { loginId: '2025090074', front: '780305', back: '2348044' },
    { loginId: '2025090480', front: '680216', back: '1519929' },
    { loginId: '2025090121', front: '731124', back: '2540616' },
    { loginId: '2025090319', front: '650530', back: '2449110' },
    { loginId: '2025090089', front: '760121', back: '1812335' },
    { loginId: '2025090108', front: '830113', back: '1631714' },
    { loginId: '2025090090', front: '821004', back: '1478311' },
    { loginId: '2025090126', front: '790909', back: '2048231' },
    { loginId: '2025090051', front: '700123', back: '6200191' },
    { loginId: '2025090287', front: '760329', back: '1630419' },
    { loginId: '2025090225', front: '750627', back: '2702618' },
    { loginId: '2025090216', front: '760511', back: '2455813' },
    { loginId: '2025090088', front: '710805', back: '1566412' },
    { loginId: '2025090380', front: '760418', back: '1558611' },
    { loginId: '2025090317', front: '770515', back: '2241110' },
    { loginId: '2025090203', front: '570519', back: '1026111' },
    { loginId: '2025090219', front: '700527', back: '2337417' },
    { loginId: '2025100287', front: '840304', back: '6100373' },
    { loginId: '2025090058', front: '', back: '' },
  ];

  console.log(`🚀 총 ${usersToUpdate.length}명 업데이트 시작...`);

  for (const item of usersToUpdate) {
    const user = await userRepo.findOne({ where: { loginId: item.loginId } });

    if (user) {
      // 값만 넣어주면 @Column({ transformer: ... }) 설정에 의해
      // save() 시점에 자동으로 암호화됩니다.
      user.residentIdFront = item.front;
      user.residentIdBack = item.back; // 평문 입력 -> 자동 암호화 저장

      await userRepo.save(user);
      console.log(`Updated: ${item.loginId}`);
    } else {
      console.warn(`User not found: ${item.loginId}`);
    }
  }

  console.log(' 모든 작업 완료!');
  await dataSource.destroy();
}

seed().catch((err) => {
  console.error('Error during seeding:', err);
});
