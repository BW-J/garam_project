export enum PositionCode {
  SFP = 'FP', // 기존 DESIGNER -> SFP로 변경
  MANAGER = 'MANAGER',
  DIRECTOR = 'DIRECTOR',
  CEO = 'CEO',
}
