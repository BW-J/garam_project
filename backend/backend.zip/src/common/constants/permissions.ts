export enum MenuCode {
  DASH_BOARD = 'DASH_BOARD',
  USER = 'USER',
}
export enum ActionCode {
  CREATE = 'CREATE',
  VIEW = 'VIEW',
  UPDATE = 'UPDATE',
  DELETE = 'DELETE',
}
